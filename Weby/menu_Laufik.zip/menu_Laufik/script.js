const menubutton = document.querySelector("nav div:nth-child(3) button:nth-child(2)");
const menu = document.querySelector(".flex-container");
const closebutton = document.querySelector(".flex-container li:nth-child(5)");

menubutton.addEventListener("click", () => {
    menu.style.left = "0%";
    menu.style.right = "0%";
    menubutton.style.display = "none"
})

closebutton.addEventListener("click", () => {
    menu.style.left = "-200%";
    menu.style.right = "200%";
    menubutton.style.display = "initial"
})