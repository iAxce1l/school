<footer>
    <p class="border-top text-center text-white fs-5 align-items-center justify-content-center" style="background-color: rgb(17, 8, 36); padding: 0; margin: 0;">Dávid Laufik 2023 ODP</p>
</footer>